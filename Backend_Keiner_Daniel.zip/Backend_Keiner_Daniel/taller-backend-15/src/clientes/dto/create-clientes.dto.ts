export class CreateUserDto {
  nombre: string;
  email: string;
  telefono: string;
}
