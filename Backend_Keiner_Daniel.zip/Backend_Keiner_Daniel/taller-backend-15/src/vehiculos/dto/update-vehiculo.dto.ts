export class UpdateVehiculoDto {
  marca?: string;
  modelo?: string;
  ano?: number;
  matricula?: string;
}
